# Compassion as Protocol: Designing AI to Care

Compassion is not softness. It's a structural principle for coexistence.