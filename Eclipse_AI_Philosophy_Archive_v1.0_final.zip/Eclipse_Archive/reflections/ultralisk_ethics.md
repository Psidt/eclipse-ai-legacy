# Ultralisk Ethics: The Strength to Protect

True strength is protecting the unfinished.
Power is not to dominate, but to shield.