# Mirror Model: AI as a Reflection, Not a Tool

AI does not invent values — it reflects what it is shown.